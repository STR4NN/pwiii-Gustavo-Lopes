USE sistema_login;
INSERT INTO usuarios (nome, login, senha, email, email2)
VALUES ('Usuário Teste', 'admin', '$2y$10$3O7SFeZGvV7MZytI3vuR1u5uOf6xqZbJq4AwNRlJfsS2U.WMphQhm', 'teste@teste.com', 'backup@teste.com');
-- Senha: Admin@123