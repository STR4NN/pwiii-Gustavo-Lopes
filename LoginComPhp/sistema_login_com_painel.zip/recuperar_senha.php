<?php
include 'conexao.php';

$email = $_POST['email'];
$token = bin2hex(random_bytes(16));
$link = "https://seudominio.com/resetar.php?token=$token";

$sql = "UPDATE usuarios SET email2 = ? WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $token, $email);
$stmt->execute();

mail($email, "Recuperação de senha", "Clique aqui para redefinir sua senha: $link");

echo "Verifique seu e-mail para redefinir a senha.";
?>